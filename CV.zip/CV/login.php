<?php
session_start();
?>
	<form name="login" action="login.php" method="post">
		User Name:<input type="text" name="un" /><br/><br/>
		Password:<input type="password" name="pw"/><br/><br/><br/>
		<input type="Submit" name="submit" />
	</form>

<?php

$user = array(
	"fahim"=>"123", 
	"saef"=>"Pass"); 
	

$flag=0;

foreach($user as $un=> $pass)
{
	if($_SERVER['REQUEST_METHOD']== "POST")
	{
		if($_POST['un']== $un && $_POST['pw']== $pass)
		{
			$_SESSION['un']= $un;
			header("location:home.php");
			$flag=1;
			break;
		}
		else
		{
			$flag=2;
		}
	}
}

if($flag==2)
{
	echo "Wrong Username or Password";
}

if(isset($_SESSION['flag1']))
{
	echo "You're Logged out";
    session_destroy();
}
else
{
	echo "";
}

?>