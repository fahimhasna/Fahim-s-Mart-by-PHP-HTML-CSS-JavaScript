<?php
    setcookie("submit", "1", time()+86400, "/");
	echo "Be first to be a member and win a lucky coupon!"
?>
<?php
    $nameErr = $emailErr = $genderErr = "";
    $name = $email = $gender = $comment = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["name"])) {
    $nameErr = "Name is required";
  } else {
    $name = test_input($_POST["name"]);
    // check if name only contains letters and whitespace
    if (!preg_match("/^[a-zA-Z ]*$/",$name)) {
      $nameErr = "Only letters and white space allowed";
    }
  }
  if (empty($_POST["name"])) {
    $nameErr = "Name is required";
  } else {
    $name = test_input($_POST["name"]);
    // check if name only contains letters and whitespace
    if (!preg_match("/^[a-zA-Z ]*$/",$name)) {
      $nameErr = "Only letters and white space allowed";
    }
  }
  
  if (empty($_POST["email"])) {
    $emailErr = "Email is required";
  } else {
    $email = test_input($_POST["email"]);
    // check if e-mail address is well-formed
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $emailErr = "Invalid email format";
    }
  }
  if (empty($_POST["gender"])) {
    $genderErr = "Gender is required";
  } else {
    $gender = test_input($_POST["gender"]);
  }
}

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>
<html>
<head>
<style>
.error {color: #FF0000;}
.submit {color: #FF0000;}
</style>
<title>FahimBoy.haha</title>
</head>
<body>
<h1 style="background-color:crimson;">MY FORM</h1>
<p><span class="error">* required field</span></p>
<form style="background-color:DarkSeaGreen;" method="post" action=""> 
    Username: <input style="background-color:yellow" type = "text" name = "name" value="<?php echo $name;?>"><span class="error">* <?php echo $nameErr;?></span><br><br>
    Full Name: <input style="background-color:yellow" type = "text" name = "name" value="<?php echo $name;?>"><span class="error">* <?php echo $nameErr;?></span><br><br>
    Email: <input style="background-color:yellow" type="text" name="email" value="<?php echo $email;?>"><span class="error">* <?php echo $emailErr;?></span><br><br>
    Phone: <input style="background-color:yellow" type = "text" name = ""/><br/><br/>
    Password: <input style="background-color:yellow" type = "password" name = "pass"/><br/><br/>
    Re-type Password: <input style="background-color:yellow" type = "text" name = "pass"/><br/><br/>
    Gender: <input type = "radio" name = "gender" value = "male"/>Male <input type = "radio" name = "gender" value = "female"/>Female <input type = "radio" name = "gender" value = "other"/>Other <br/><br/>
    Education: <input type="checkbox" name="education" value="HSC">HSC <input type="checkbox" name="education" value="SSC">SSC <input type="checkbox" name="education" value="JSC">JSC <input type="checkbox" name="education" value="PSC">PSC <br/><br/>
<input style="background-color:gray; font-size:19px" type = "submit" value="SUBMIT" name="submit" href="location:login.php">

                <p>Already have an account? <a href="login.php">Sign in</a>.</p>
            </div>
        </form>
    </div>

</body>

</html>