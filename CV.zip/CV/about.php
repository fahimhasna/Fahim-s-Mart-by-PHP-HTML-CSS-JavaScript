<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Resume</title>
  <table style ="background-color: #668284;" border="1" align="center"  height="40px;" width=" 98%;"  margin-bottom = "10px">
  <tr>
  <th> 	<h1 style="color:LightGray;"  align="center"> Resume <Br>of<br> Abu Hasna Mohammed Fahim Munna</h1></th>
  </table>
</head>

<body>
	

			
	<img src="rafi.jpg" alt="Profile picture" align="Right" height = "120;" width = "120;"></th></table>
	</p>
		<p>
		<h2 align="Left">Personal Details:</h2>
			<ul>
                <li align="Left"> Father Name: Mohammed Abdur Razzaque</li>
				<li > Religion: Islam</li>
				<li> Date of birth: 7th of June, 1997</li>
				<li> Nationality: Bangladeshi</li>
				<li> Marital Status: Single</li>
              
            </ul>
	</p>
	
</body>
</html>
	
	