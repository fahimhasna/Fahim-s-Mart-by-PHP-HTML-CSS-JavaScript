<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Personal Information</title>
</head>

<body>
    <div class="container">
        <!--        navbar start-->
        <div class="topnav">
          
            <a href="about.php">ABOUT</a>
            <a href="contact.php">CONTACT</a>
            
                <a href="login.php" align="center">SIGN IN</a>
                <a href="registration.php"  align="center">REGISTER</a>
            </div>
        <div>
                <h1>Abu Hasna Mohammed Fahim Munna</h1>
                <a href="#" >
                <img src="fahim.jpg" alt="Photo" width="120px" height="120px">
            </a>
        </div>
        
     <div>
            <a href="Education.php">Education</a>
            <a href="Skill.html">Skill</a>
         
        
        
     </div>   


    </div>
</body>

</html>