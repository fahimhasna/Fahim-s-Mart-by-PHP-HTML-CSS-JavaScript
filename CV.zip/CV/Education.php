<html>
<head>

</head>
<body>
    <table style ="background-color:LightGray;" border="1"   height="100px;" width=" 98%;"  margin-bottom = "10px">
	   <p><tr>	
	   <th > 
           <h2 align="Left">Academic Qualifications</h2>
			<table style =<table style ="background-color: #668284;" border="1" align="center"  height="40px;" width=" 50%;">
            <tr > <border="1" align="left"  height="40px;" width=" 50%;">
            <tr > <th style="color:magenta;" >Qualification</th> <th style="color:magenta;">Board</th> <th style="color:magenta;">Grades</th> <th style="color:magenta;">Year</th> </tr>
			<tr > <th >BSC in CSE</th> <th >Dhaka</th> <th >3.50</th> <th >Continuing...(118 credit completed)</th> </tr>
			<tr > <th >H.S.C.</th> <th >Dhaka</th> <th >4.50</th> <th >2015</th> </tr>
			<tr > <th >S.S.C.</th> <th >Dhaka</th> <th >5.00</th> <th >2013</th> </tr>
        </th>
</body>
</html>