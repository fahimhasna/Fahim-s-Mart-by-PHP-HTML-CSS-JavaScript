<?php

//require 'config.php';

echo "hello";
$name=$_POST['name'];
$email=$_POST['email'];
$password=$_POST['psw'];
$contact=$_POST['contact'];
$address=$_POST['address'];

//insertion
setcookie('name',password,time()+(86400*30),"/");
echo $_COOKIE[$name];
?>

<html>
    <body>
        <?php
         if(!isset($_COOKIE[$name]))
         {
             echo"User not set";
         }
        else{
            echo"User is set";
            echo"value is .$_COOKIE[$name]";
        }
        ?>
    </body>
</html>