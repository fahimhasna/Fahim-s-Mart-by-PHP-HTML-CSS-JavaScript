<?php
    setcookie('test','OK',time()+3600);
    echo $_COOKIE['test'];
    
?>