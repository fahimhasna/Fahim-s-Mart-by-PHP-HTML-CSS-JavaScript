<?php
	session_start();
	header("location:login.php");
?>
