<?php
	session_start();
	if(!isset($_SESSION['un'])){
		header("location:login.php");
	}
	else{
        $_SESSION['flag1']= 0;
		echo "Welcome  ".$_SESSION['un'];
		echo"<br/>";
		echo "<br/><a href='logout.php'>Logout</a>";
	}

?>