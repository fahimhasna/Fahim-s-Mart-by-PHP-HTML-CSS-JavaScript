<?php ?>
<html>
<head>
    <title>BU</title>
	<link href='style.css' rel='stylesheet'>
</head>

<body>

    <header>
	   <div class="row">
		<ul class="main-nav1">
		    <li class="active"><a href="#">Students</a></li>
			<li><a href="#">Staff</a></li>
			<li><a href="#">Alumni</a></li>
			<li><a href="#">myHub</a></li>
		</ul>
	    </div>
		
		<div class="neon1">
		  <input name="" type="text">
            <input value="Search" type="button">
	    </div>	
	 </header>
	 
	<div class="neon">
		    <img style="display:inline; width:400; height:40;background-color:white;"; align="left"; src="BU.png";/>
	    </div>
		
		<div class="row">
		<ul class="main-nav">
		    <li class="active"><a href="#">Home</a></li>
			<li><a href="#">Why BU?</a></li>
			<li><a href="#">Study</a></li>
			<li><a href="#">Research</a></li>
			<li><a href="#">Collaborate</a></li>
			<li><a href="#">Global BU</a></li>
			<li><a href="#">About</a></li>
		</ul>
		</div>
		
		<div class="div3">
		    <a class="test" href="#">Why BU?</a>
			<a class="test" href="#">Thems</a>
			<a class="test" href="#">Centres</a>
			<a class="test" href="#">Impact</a>
			<a class="test" href="#">Environment</a>
			<a class="test" href="#">Postgraduate</a>
			<a class="test" href="#">Our latest research</a>
			<a class="test" href="#">Research Chronicle</a>
			<a class="test" href="#">undergraduate</a>
			<br/>
			<a class="test" href="#">British Conference of Undergraduate Research</a>
			<a class="test" href="#">Showcasing Undergraduate Research Excellence</a>
		</div>
		
		<div class="image">
		   
		</div>
		
		<div class="text">
		    <h4 data="text">Our research shapes and changes the world around us, providing solutions to real-world problems and informing the education we deliver. Our Students are a key part of the research we conduct, co-creating knowledge with us and  playing a crucial role in everything that we do.</h4>
	    </div>
		
	           
</body>
</html>