<?php
require("dataloader.php");
$cred=array();

//loadFromFile();
//loadFromXML();

loadFromMySQL("select * from users");


$uname=$_POST["uname"];
$pass=$_POST["pass"];


$v=0;
$_SESSION["flag"]="";


session_start();
$_SESSION["username"]=$_POST["uname"];

foreach($cred as $a){

if($uname == $a["un"] && $pass == $a["pass"] && $a["memtype"] == "admin")
{

	$v=1;
	$_SESSION["flag"]="success";
	header("Location:AdminPage.php"); 
	
	
}
elseif($uname == $a["un"] && $pass == $a["pass"] && $a["memtype"] == "member")
{
	$v=1;
	$_SESSION["flag"]="success";
	header("Location:userProfile.php"); 
	
}

}
if($v==0)
{
	echo "Invalid Credentials";	
	//echo "<pre>";print_r($cred);echo "</pre>";
}
echo "<pre>";print_r($cred);echo "</pre>";

?>

