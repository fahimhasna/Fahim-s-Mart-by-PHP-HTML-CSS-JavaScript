<?php

	
function loadFromMySQL($sql){
	global $cred;	
	$conn = mysqli_connect("localhost", "root", "","pharma");
	//echo $sql;
	$result = mysqli_query($conn, $sql)or die(mysqli_error($conn));
	$cred=array();
	//print_r($result);
	while($row = mysqli_fetch_assoc($result)) {
		//print_r($row);
		$ar=array();
		//$ar["fname"]=$row["fsname"];
		//$ar["lname"]=$row["ltname"];
		$ar["un"]=$row["uname"];
		//$ar["dob"]=$row["dob"];
		//$ar["mail"]=$row["mail"];
		//$ar["pnumb"]=$row["phnumb"];
		$ar["pass"]=$row["password"];
		//$ar["cpass"]=$row["cpassword"];
		$ar["memtype"]=$row["mtype"];
		//$ar["stat"]=$row["status"];
		
		$cred[]=$ar;
	}
	//return $arr;
}	
	

?>