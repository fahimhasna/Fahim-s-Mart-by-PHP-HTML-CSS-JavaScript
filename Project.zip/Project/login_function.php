<?php
function loadFromFile(){
	global $cred;
	$myfile = fopen("login.php", "r") or die("Unable to open file!");
	while($line=fgets($myfile)){
		$line=trim($line);
		$cr=explode(" ",$line);
		//echo trim($line) ;
		//echo "<pre>";print_r($cr);echo "</pre>";
		
		$dar=array("un"=>$cr[0],"pass"=>$cr[1], "type"=>$cr[2]);
		
		//$dar[$cr[0]]=$cr[1];
		
		$cred[]=$dar;
	}
	fclose($myfile);
}
 function loadFromXML(){
	global $cred;
	$xml=simplexml_load_file("login.xml") or die("Error: Cannot create object");
	foreach($xml as $st){
		$dar=array();
		$dar["un"]=(string)$st->name;
		$dar["pass"]=(string)$st->pass;
		$dar["type"]=(string)$st->type;
		
		
		
		
		
		$cred[]=$dar;
	} 
	//fclose($file);
 }
?>