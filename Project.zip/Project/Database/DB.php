<?php

$dbServerName = "localhost";
$dbUserName ="root";
$dbPassword = "";
$dbName = "pharma";

$conn = mysqli_connect($dbServerName,$dbUserName,$dbPassword,$dbName);


?>