
<!doctype html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8"/>
	<link rel="stylesheet" href="c4.css" type="text/css"/>
	</head>
	<body>

	
	<?php 
	/*
//echo "<pre>";print_r($GLOBALS);echo "</pre>";
?>
<p style="color:red;">
<?php 
if(isset($_REQUEST["error"]))echo $_REQUEST["error"];

*/

?>
</p>

	<form class="login" action="logcheck.php"border="1px" method="post">
   <table   style="border: 4px solid gray;">
   
   <tr>
   <td>
   <span style="color:green; font-size:50px " >GreenLeaf Pharma</a>
 
   <pre style="font-size:15px"  >
   <b>Get us,
   Save Life!</pre>
   </b>
   </td>
   <tr>
   
 
   
   <tr>
   <td>
	<input  type="text" name="uname"  style="color:gray ;height:35px; width:300px"   placeholder="username" /><br>
	
	<?php
	/* value="username" */
	?>
   </td>
   </tr>
   
   <tr>
   <td>
    <input type="password" name="pass" style="height:40px; width:300px"  placeholder="password" /><br>
   </td>
   </tr>
   <tr>
   <td>
<input  type="submit" value="Login" style="height:40px; width:305px; background-color:green;" href="AdminPage.php" /><br>
</td>



</tr>
   
   <tr>
   <td>
   <a href="index.html" >back</a>
   

   </td>
   
   </tr>
   </table>
   </body>
   
   </html>