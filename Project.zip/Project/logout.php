<?php
session_start();
$_SESSION["flag"]="";
header("Location:login.php");
?>